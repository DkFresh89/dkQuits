-- Create password_resets table for handling password reset tokens
CREATE TABLE IF NOT EXISTS password_resets (
    user_id VARCHAR(36) PRIMARY KEY,
    token VARCHAR(36) NOT NULL UNIQUE,
    expires_at TIMESTAMP NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- Index for token lookup
CREATE INDEX idx_password_resets_token ON password_resets(token);

-- Index for expiration cleanup
CREATE INDEX idx_password_resets_expires ON password_resets(expires_at);
