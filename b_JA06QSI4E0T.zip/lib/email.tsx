export async function sendPasswordResetEmail(email: string, name: string, resetToken: string): Promise<void> {
  const apiKey = process.env.RESEND_API_KEY

  if (!apiKey) {
    console.log("[v0] Password reset email (no API key configured):")
    console.log(`To: ${email}`)
    console.log(`Reset Token: ${resetToken}`)
    console.log(
      `Reset URL: ${process.env.NEXT_PUBLIC_APP_URL || "http://localhost:3000"}/reset-password?token=${resetToken}`,
    )
    return
  }

  const resetUrl = `${process.env.NEXT_PUBLIC_APP_URL || "http://localhost:3000"}/reset-password?token=${resetToken}`

  try {
    const response = await fetch("https://api.resend.com/emails", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${apiKey}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        from: "onboarding@resend.dev",
        to: email,
        subject: "Reset Your Password - Quit Smoking App",
        html: `
          <h1>Password Reset Request</h1>
          <p>Hi ${name},</p>
          <p>You requested to reset your password. Click the link below to reset it:</p>
          <p><a href="${resetUrl}">Reset Password</a></p>
          <p>This link will expire in 1 hour.</p>
          <p>If you didn't request this, please ignore this email.</p>
        `,
      }),
    })

    if (!response.ok) {
      throw new Error(`Resend API error: ${response.statusText}`)
    }
  } catch (error) {
    console.error("[v0] Failed to send password reset email:", error)
    throw error
  }
}
